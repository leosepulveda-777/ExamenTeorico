package Taller1;

public class Cliente {

	public Cliente() {
		// TODO Auto-generated constructor stub
	}

}
