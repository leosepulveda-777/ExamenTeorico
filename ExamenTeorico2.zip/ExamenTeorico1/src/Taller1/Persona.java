package Taller1;

public abstract class Persona {

}
