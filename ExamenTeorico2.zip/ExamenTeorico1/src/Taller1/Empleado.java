package Taller1;

public class Empleado {

	public Empleado() {
		// TODO Auto-generated constructor stub
	}

}
