package Taller1;

public class Mesa {

	public Mesa() {
		// TODO Auto-generated constructor stub
	}

}
