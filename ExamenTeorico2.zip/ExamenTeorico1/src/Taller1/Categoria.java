package Taller1;

public class Categoria {

	public Categoria() {
		// TODO Auto-generated constructor stub
	}

}
