package Taller1;

public class Pedido {

	public Pedido() {
		// TODO Auto-generated constructor stub
	}

}
